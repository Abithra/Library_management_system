package objects;

import java.time.YearMonth;
import java.util.Date;

public class OverDueItem  {

    public int getDays(String y,String m, String d)
    {
        int days=0;

        MonthDays monthDays = new MonthDays();
        int month = monthDays.daysOfMonth(m);
        String[] mon = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
       for (int i=0;i<month-1;i++)
       {
           YearMonth yearMonthObject = YearMonth.of(Integer.parseInt(y),new MonthDays().daysOfMonth(mon[i]));
           int daysInMonth = yearMonthObject.lengthOfMonth(); //28
           days=days+daysInMonth;

       }


        return days+Integer.parseInt(d);
    }

    public int dueDays(String borrowedDate)
    {
        Date date = new Date();
        String[] s = date.toString().split(" ");
        String [] b = borrowedDate.split(",");
        int dueDays = 0;

        int currentYear = Integer.parseInt(s[5]);
        int borrowedYear = Integer.parseInt(b[2]);
        int curDay = getDays(s[5],s[1],s[2]);
        int borDay = getDays(b[2],b[0],b[1]);
        if(borDay<=curDay)
        {
            dueDays = (curDay-borDay)+(currentYear-borrowedYear)*365;
        }
        else
        {
            dueDays =((curDay+365)-borDay)+((currentYear-1)-borrowedYear)*365;
        }

      return dueDays;
    }

    public int duehours(String borrowedDate)
    {
        Date date = new Date();
        String[] s = date.toString().split(" ");
        String [] b = borrowedDate.split(",");
        int dueDays = 0;

        int currentYear = Integer.parseInt(s[5]);
        int borrowedYear = Integer.parseInt(b[2]);
        int curDay = getDays(s[5],s[1],s[2]);
        int borDay = getDays(b[2],b[0],b[1]);
        if(borDay<=curDay)
        {
            dueDays = (curDay-borDay)+(currentYear-borrowedYear)*365;
        }
        else
        {
            dueDays =((curDay+365)-borDay)+((currentYear-1)-borrowedYear)*365;
        }

        int curhour = Integer.parseInt(s[3].split(":")[0]);
        int burhour = Integer.parseInt(b[3].trim().split(":")[0]);

        int duehour;
        if(burhour>=curhour)
        {
            duehour = (curhour - burhour) + (dueDays * 24);

        }
        else
        {
            duehour = ((curhour+24) - burhour) + ((dueDays-1) * 24);

        }
        return duehour;
    }

    public double due(String borrowedDate, String type)
    {
        double due = 0;
        int duedays = dueDays(borrowedDate);
        if(type.equals("BOOK")) {
            if (duedays > 7) {
                int bookDue = duedays - 7;
                if (bookDue <= 3) {
                    due = (duehours(borrowedDate) - (7 * 24)) * 0.2;
                } else {
                    due = (3 * 24 * 0.2) + (duehours(borrowedDate) - (10 * 24)) * 0.5;
                }
            }
        }
        if(type.equals("DVD")) {
            if (duedays > 3) {
                int dvdDue = duedays - 3;
                if (dvdDue <= 3) {
                    due = (duehours(borrowedDate) - (3 * 24)) * 0.2;
                } else {
                    due = (3 * 24 * 0.2) + (duehours(borrowedDate) - (6 * 24)) * 0.5;
                }
            }
        }

       return due;
    }
}

