package objects;

public interface LibraryManager  {

    public String getUserName();
    public void setUserName(String userName);
    public String getPassword();
    public void setPassword(String password);

}
