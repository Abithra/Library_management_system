package objects;

import io.ebean.Model;

public class SearchItem extends Model {

    String searchKey;

    public String getSearchKey() {
        return searchKey;
    }

    public void setSearchKey(String searchKey) {
        this.searchKey = searchKey;
    }
}
