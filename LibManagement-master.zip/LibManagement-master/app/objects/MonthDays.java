package objects;

public class MonthDays {
    public int daysOfMonth(String s)
    {
       int month = 0;
        String [] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
       for(int i=0;i<months.length;i++)
       {
           if(s.equals(months[i]))
           {
               month= i+1;
               break;
           }
       }
       return month;
    }
}
