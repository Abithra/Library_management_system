package objects;

import java.util.Date;

public class DateTime {



    public String DateTime() {

        Date date = new Date();
        String[] s = date.toString().split(" ");
        String finalDate = s[1].trim()+","+s[2].trim()+","+s[5].trim()+", "+s[3].trim();
        return finalDate;
    }



}
