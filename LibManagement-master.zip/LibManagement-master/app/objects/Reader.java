package objects;

public class Reader {
    private int id;
    private String name;
    private int mobileNo;
    private String email;
}
