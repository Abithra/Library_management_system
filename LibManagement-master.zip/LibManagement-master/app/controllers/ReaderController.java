package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import javax.inject.Inject;
import model.Reader;
import play.data.FormFactory;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import static play.libs.Json.toJson;

public class ReaderController extends Controller {

    @Inject FormFactory formFactory;

    public Result addReader()
    {
        JsonNode body = request().body().asJson();
        if(body.get("name") != null) {
            Reader reader = new Reader();
            reader.setName(body.get("name").asText());
            reader.setMobileNo(body.get("mobile").asInt());
            reader.setEmail(body.get("email").asText());
            reader.save();
            JsonNode jsonNode = Json.toJson(new AppSummary("Reader added successfully"));
            return ok(jsonNode).as("application/json");
        }
        else
        {
            JsonNode jsonNode = Json.toJson(new AppSummary("Some thing wrong in add Reader"));
            return ok(jsonNode).as("application/json");
        }
    }

    public Result listReader()
    {
        List<Reader> bookList = Reader.find.all();

        return ok(toJson(bookList)).as("application/json");
    }
}
