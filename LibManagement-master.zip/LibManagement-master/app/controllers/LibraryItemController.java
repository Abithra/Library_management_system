package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.inject.Inject;
import model.Book;
import model.Bookings;
import model.DVD;
import model.LibraryItem;
import model.Reader;
import objects.BorrowItem;
import objects.DateTime;
import objects.OverDueItem;
import objects.OverDues;
import objects.SearchItem;
import play.data.FormFactory;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import static play.libs.Json.toJson;

public class LibraryItemController extends Controller {

    @Inject private
    FormFactory formFactory;

    //add Library Item

    public Result addItem()
    {
        String[] postAction = request().body().asFormUrlEncoded().get("action");
        if (postAction == null || postAction.length == 0) {
            return badRequest("You must provide a valid action");
        } else {
            String type = postAction[0];
            if (type.equals("BOOK")) {
                return redirect(routes.HomeController.book());
            } else {
                return redirect(routes.HomeController.dvd());
            }
        }
    }

    public Result deleteItem()
    {
      SearchItem searchItem = formFactory.form(SearchItem.class).bindFromRequest().get();
        LibraryItem libraryItem = LibraryItem.find.byId(Long.valueOf(Long.valueOf(searchItem.getSearchKey())));
        String msg = "";
        if (libraryItem != null) {
            if(libraryItem.getSector().equals("BOOK"))
            {
               Objects.requireNonNull(Book.find.byId(libraryItem.getIsbn())).delete();
               msg=libraryItem.getSector();
               libraryItem.delete();
            }
            else {
                Objects.requireNonNull(DVD.find.byId(libraryItem.getIsbn())).delete();
                msg=libraryItem.getSector();
                libraryItem.delete();
            }

        }
        List<Book>bookList = Book.find.all();
        List<DVD>dvdList = DVD.find.all();
        JsonNode jsonNode = toJson(new AppSummary("You have deleted a "+msg+". There are "
            +(100-bookList.size())+ "space for book and "+(50-dvdList.size())
            +" space for dvd are available."));
        return ok(jsonNode).as("application/json");
    }

    public Result searchItem()
    {
        SearchItem searchItem = formFactory.form(SearchItem.class).bindFromRequest().get();
        LibraryItem libraryItem = new LibraryItem();

        List<LibraryItem> libraryItemList = LibraryItem.find.all();
        for (LibraryItem item : libraryItemList) {
            if(item.getTitle().toLowerCase().equals(searchItem.getSearchKey().toLowerCase()))
            {
                libraryItem = item;

            }
        }
        if(libraryItem.getTitle()!=null)
        {
            return ok(toJson(libraryItem)).as("application/json");
        }
        else
        {
            return ok(toJson("Search Item not found")).as("application/json");
        }
    }

    public Result listBook()
    {
        List<Book> bookList = Book.find.all();
        List<LibraryItem> libraryItemList = LibraryItem.find.all();
        List<objects.Book> books = new ArrayList<>();
        for (Book book : bookList) {
            for (LibraryItem libraryItem : libraryItemList) {
                if (book.getIsbn()==libraryItem.getIsbn())
                {
                    objects.Book book1 = new objects.Book();
                    book1.setIsbn(libraryItem.getIsbn());
                    book1.setTitle(libraryItem.getTitle());
                    book1.setSector(libraryItem.getSector());
                    book1.setPublicationDate(libraryItem.getPublicationDate());
                    book1.setBorrowedDate(libraryItem.getBorrowedDate());
                    book1.setCurrentReader(libraryItem.getCurrentReader());
                    book1.setAuthors(book.getAuthors());
                    book1.setPublisher(book.getPublisher());
                    book1.setNoOfPages(book.getNoOfPages());
                   books.add(book1);
                }

            }

        }


        return ok(toJson(books)).as("application/json");
    }
    public Result addBook()
    {
        JsonNode body = request().body().asJson();
        int noOfBooks = Book.find.all().size();

    if(noOfBooks<=100){
        LibraryItem libraryItem = new LibraryItem();
        libraryItem.setIsbn(Long.parseLong((body.get("isbn").asText())));
        libraryItem.setTitle( body.get("title").asText());
        libraryItem.setPublicationDate( body.get("pubDate").asText());
        libraryItem.setSector("BOOK");
        libraryItem.save();

        Book bookModel = new Book();
        bookModel.setIsbn(Long.parseLong(body.get("isbn").asText()));
        bookModel.setAuthors( body.get("author").asText());
        bookModel.setPublisher( body.get("publisher").asText());
        bookModel.setNoOfPages( body.get("noOfPages").asText());
        bookModel.save();

        JsonNode jsonNode = Json.toJson(new AppSummary("Success fully added a book! There are "+
            (noOfBooks+1) +"in the library. You can add "+(100-(noOfBooks+1))+"more!"));
        return ok(jsonNode).as("application/json");
        }
else {
    JsonNode jsonNode = Json.toJson(new AppSummary("No space"));
    return ok(jsonNode).as("application/json");
}
    }
    public Result listDVD()
    {
       List<DVD>dvdList = DVD.find.all();
       List<LibraryItem> libraryItemList = LibraryItem.find.all();
       List<objects.DVD> dvds = new ArrayList<>();
        for (DVD dvd : dvdList) {
            for (LibraryItem libraryItem : libraryItemList) {
                if(dvd.getIsbn()==libraryItem.getIsbn())
                {
                    objects.DVD dvd1 = new objects.DVD();
                    dvd1.setIsbn(libraryItem.getIsbn());
                    dvd1.setTitle(libraryItem.getTitle());
                    dvd1.setSector(libraryItem.getSector());
                    dvd1.setPublicationDate(libraryItem.getPublicationDate());
                    dvd1.setBorrowedDate(libraryItem.getBorrowedDate());
                    dvd1.setCurrentReader(libraryItem.getCurrentReader());
                    dvd1.setLanguages(dvd.getLanguages());
                    dvd1.setSubtitles(dvd.getSubtitles());
                    dvd1.setProducer(dvd.getProducer());
                    dvd1.setActors(dvd.getActors());

                    dvds.add(dvd1);

                }

            }

        }


        return ok(toJson(dvds)).as("application/json");

    }
    public Result addDVD()
    {
        JsonNode body = request().body().asJson();
        int noOfDVDs = DVD.find.all().size();
     if(noOfDVDs<=50) {

         objects.DVD dvd = formFactory.form(objects.DVD.class).bindFromRequest().get();
         LibraryItem libraryItem = new LibraryItem();
         libraryItem.setIsbn(dvd.getIsbn());
         libraryItem.setTitle(dvd.getTitle());
         libraryItem.setPublicationDate(dvd.getPublicationDate());
         libraryItem.setSector("DVD");
         libraryItem.save();

         DVD dvdModel = new DVD();
         dvdModel.setIsbn(dvd.getIsbn());
         dvdModel.setLanguages(dvd.getLanguages());
         dvdModel.setSubtitles(dvd.getSubtitles());
         dvdModel.setProducer(dvd.getProducer());
         dvdModel.setActors(dvd.getActors());
         dvdModel.save();

         JsonNode jsonNode = toJson(new AppSummary("Success fully added a dvd! There are "+
             (noOfDVDs+1) +"in the library. You can add "+(50-(noOfDVDs+1))+"more!"));
         return ok(jsonNode).as("application/json");
     }
     else
     {
         JsonNode jsonNode = toJson(new AppSummary("No space in Library"));
         return ok(jsonNode).as("application/json");
     }
    }
    public Result listLibraryItem()
    {
        List<LibraryItem> libraryItemList = LibraryItem.find.all();
        return ok(toJson(libraryItemList)).as("application/json");
    }

    public Result borrowItem()
    {
        BorrowItem borrowItem = formFactory.form(BorrowItem.class).bindFromRequest().get();

        LibraryItem libraryItem = LibraryItem.find.byId(Long.valueOf(Long.valueOf(borrowItem.getIsbn())));
        Reader reader = Reader.find.byId(Integer.valueOf(borrowItem.getReaderId()));
        String message = "";
        if(libraryItem!=null && reader!=null)
        {
            if(libraryItem.getCurrentReader()==null)
            {

                libraryItem.setCurrentReader(reader.getName());
                DateTime dateTime = new DateTime();
                libraryItem.setBorrowedDate(dateTime.DateTime());
                libraryItem.save();
                if(libraryItem.getSector().equals("BOOK"))
                {
                    message="Have to return in 7 days";
                }
                else
                    message = "Have to return in 3 days";
            }
            else
            {
                Bookings bookings = new Bookings();
                bookings.setIsbn(libraryItem.getIsbn());
                bookings.setBookingDate(String.valueOf(new Date()));
                bookings.setReader(reader.getId());
                bookings.save();
                message="Book is not available! Some one have taken! Available after "+libraryItem.getBorrowedDate();
            }
        }
        else
            message="User ID or ISBN is wrong";
         JsonNode jsonNode = toJson(new AppSummary(message));
        return ok(jsonNode).as("application/json");
    }

    public Result returnItem()
    {
        SearchItem searchItem = formFactory.form(SearchItem.class).bindFromRequest().get();
        LibraryItem libraryItem = LibraryItem.find.byId(Long.valueOf(Long.valueOf(searchItem.getSearchKey())));
        double due = 0;
        if(libraryItem!=null)
        {
            OverDueItem overDueItem = new OverDueItem();
            due =overDueItem.due(libraryItem.getBorrowedDate(),libraryItem.getSector());
            libraryItem.setBorrowedDate(null);
            libraryItem.setCurrentReader(null);
            libraryItem.save();
        }
        JsonNode jsonNode = toJson(new AppSummary("Your due amount is "+ due));
        return ok(jsonNode).as("application/json");
    }
    public Result genReport()
    {
        List<LibraryItem> libraryItemList = LibraryItem.find.all();
        List<OverDues> overDuesList = new ArrayList<>();
        for (LibraryItem libraryItem : libraryItemList) {
            if(libraryItem.getBorrowedDate() != null) {
                OverDueItem overDueItem = new OverDueItem();
                double due = overDueItem.due(libraryItem.getBorrowedDate(), libraryItem.getSector());
           if(due>0.1)
           {
                OverDues overDues = new OverDues();
                overDues.setIsbn(libraryItem.getIsbn());
                overDues.setSector(libraryItem.getSector());
                overDues.setFees(due);
                overDuesList.add(overDues);
           }
            }
        }

        return ok(toJson(overDuesList)).as("application/json");
    }
    public Result listBookings()
    {
        List<Bookings> bookings = Bookings.find.all();

        return ok(toJson(bookings)).as("application/json");
    }
}
