package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

class AppSummary {
    private String content;


    AppSummary(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

public class HomeController extends Controller {

    public Result appSummary() {
        JsonNode jsonNode = Json.toJson(new AppSummary("Java Play Angular Seed"));
        return ok(jsonNode).as("application/json");
    }

    public Result postTest() {
        JsonNode jsonNode = Json.toJson(new AppSummary("Post Request Test => Data Sending Success"));
        return ok(jsonNode).as("application/json");
    }

    public Result addBook() {
        JsonNode jsonNode = Json.toJson(new AppSummary("Post Request Test => Data Sending book added"));
        return ok(jsonNode).as("application/json");
    }
    public Result index() {

        return ok(); }
    public Result reader() {
        return ok();
    }
    public Result delete() {
        return ok();
    }
    public Result book() {
        return ok();
    }
    public Result dvd() {
        return ok();
    }
    public Result borrow() {return ok();}
    public Result itemReturn() {return ok();}

}
