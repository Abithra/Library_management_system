package model;

import io.ebean.Finder;
import io.ebean.Model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Bookings extends Model {
    @Id
    @GeneratedValue
    int Id;
    long isbn;
    int reader;
    String bookingDate;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public long getIsbn() {
        return isbn;
    }

    public void setIsbn(long isbn) {
        this.isbn = isbn;
    }

    public int getReader() {
        return reader;
    }

    public void setReader(int reader) {
        this.reader = reader;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public static Finder<Long, Bookings> find = new Finder<>(Bookings.class);
}
