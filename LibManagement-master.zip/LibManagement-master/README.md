# LibManSystem
LibMS 1)Create a mysql database and give the name in ProjectDirectory=> app => conf => application.cof file as follows db.default.driver=com.mysql.jdbc.Driver db.default.url="jdbc:mysql://localhost/libmansys" =>>your db db.default.username=root =>>your db user name db.default.password="" =>>your db password

Go to project directory using terminal/comand line type : sbt run After you get a message in the terminal like --- (Running the application, auto-reloading is enabled) ---

[info] p.c.s.AkkaHttpServer - Listening for HTTP on /0:0:0:0:0:0:0:0:9000

Go to your browser and check!

PreRequests You have to install Java, sbt, npm
