# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table book (
  isbn                          bigint auto_increment not null,
  authors                       varchar(255),
  publisher                     varchar(255),
  no_of_pages                   varchar(255),
  constraint pk_book primary key (isbn)
);

create table bookings (
  id                            integer auto_increment not null,
  isbn                          bigint not null,
  reader                        integer not null,
  booking_date                  varchar(255),
  constraint pk_bookings primary key (id)
);

create table dvd (
  isbn                          bigint auto_increment not null,
  languages                     varchar(255),
  subtitles                     varchar(255),
  producer                      varchar(255),
  actors                        varchar(255),
  constraint pk_dvd primary key (isbn)
);

create table library_item (
  isbn                          bigint auto_increment not null,
  title                         varchar(255),
  sector                        varchar(255),
  publication_date              varchar(255),
  borrowed_date                 varchar(255),
  current_reader                varchar(255),
  constraint pk_library_item primary key (isbn)
);

create table reader (
  id                            integer auto_increment not null,
  name                          varchar(255),
  mobile_no                     integer not null,
  email                         varchar(255),
  constraint pk_reader primary key (id)
);


# --- !Downs

drop table if exists book;

drop table if exists bookings;

drop table if exists dvd;

drop table if exists library_item;

drop table if exists reader;

