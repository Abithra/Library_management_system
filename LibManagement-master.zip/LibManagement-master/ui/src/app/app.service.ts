import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs/index';

/**
 * Class representing application service.
 *
 * @class AppService.
 */
@Injectable()
export class AppService {
  private serviceUrl = '/api/summary';
  private dataPostTestUrl = '/api/postTest';

  constructor(private http: HttpClient) {
  }

  /**
   * Makes a http get request to retrieve the welcome message from the backend service.
   */
  public getWelcomeMessage() {
    return this.http.get(this.serviceUrl).pipe(
      map(response => response)
    );
  }

  /**
   * Makes a http post request to send some data to backend & get response.
   */
  public sendData(): Observable<any> {
    console.log('send data succss');
    return this.http.post(this.dataPostTestUrl, {});
  }

  public addBook(book): Observable<any> {
    console.log('send addBook data success');
    return this.http.post('/api/addBook',book, {});
  }
  public addDVD(dvd): Observable<any> {
    console.log('send addDVD data success');
    return this.http.post('/api/addDVD',dvd, {});
  }
public addReader(reader): Observable<any> {
    console.log('send addReader data success');
    return this.http.post('/api/addReader',reader, {});
  }
public deleteItem(delkey): Observable<any> {
    console.log('send isbn data success');
    console.log(delkey);
    return this.http.post('/api/deleteItem',delkey, {});
  }
public searchItem(searkey): Observable<any> {
    console.log('send isbn data success');
    console.log(searkey);
    return this.http.post('/api/searchItem',searkey, {});
  }
public borrowItem(borrowkey): Observable<any> {
    console.log('send borrowkey data success');
    console.log(borrowkey);
    return this.http.post('/api/borrowItem',borrowkey, {});
  }
public returnItem(retkey): Observable<any> {
    console.log('send isbn data success');
    console.log(retkey);
    return this.http.post('/api/returnItem',retkey, {});
  }
public listItem(): Observable<any> {
    console.log('send Item data success');
    return this.http.get('/api/listLibraryItem').pipe(map(response => response));
  }
public listBook(): Observable<any> {
    console.log('send Book data success');
    return this.http.get('/api/listBook').pipe(map(response => response));
  }
public listDVD(): Observable<any> {
    console.log('send DVD data success');
    return this.http.get('/api/listDVD').pipe(map(response => response));
  }
public listReader(): Observable<any> {
    console.log('send Reader data success');
    return this.http.get('/api/listReader').pipe(map(response => response));
  }
public listReport(): Observable<any> {
    console.log('send report data success');
    return this.http.get('/api/genReport').pipe(map(response => response));
  }
public listBookings(): Observable<any> {
    console.log('send booking data success');
    return this.http.get('/api/listBookings').pipe(map(response => response));
  }

}
