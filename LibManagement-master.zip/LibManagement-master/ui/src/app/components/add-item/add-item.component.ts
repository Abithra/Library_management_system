import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {
  head: string;
  postRequestResponse: string;

  isbn:String;
  title:String;
  pubDate:String;
  author:String;
  publisher:String;
  noOfPages:String;
  languages:String;
  subTitles:String;
  producer:String;
  actors:String;

  itemType:string="book";

  constructor(private appService: AppService) {
    this.appService.getWelcomeMessage().subscribe((data: any) => {
    this.head = data.content;
    });
  }

  ngOnInit() {
  }

  toggleItem(itemType){
    this.itemType=itemType;
  }

   onAddBookSubmit(){
    console.log('onAddBookSubmit');
    const book = {
        isbn: this.isbn,
        title: this.title,
        pubDate: this.pubDate,
        author: this.author,
        publisher: this.publisher,
        noOfPages: this.noOfPages
    };


console.log(book);
    this.appService.addBook(book).subscribe((data: any) => {
      this.postRequestResponse = data.content;
});

}

   onAddDVDSubmit(){
    console.log('onAddDVDSubmit');
    const dvd = {
        isbn: this.isbn,
        title: this.title,
        publicationDate: this.pubDate,
        languages:this.languages,
        subtitles:this.subTitles,
        producer:this.producer,
        actors:this.actors
    };


console.log(dvd);
    this.appService.addDVD(dvd).subscribe((data: any) => {
      this.postRequestResponse = data.content;
});

}
}
