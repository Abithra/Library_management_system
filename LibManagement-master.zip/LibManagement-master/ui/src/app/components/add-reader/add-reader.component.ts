import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';


@Component({
  selector: 'app-add-reader',
  templateUrl: './add-reader.component.html',
  styleUrls: ['./add-reader.component.css']
})
export class AddReaderComponent implements OnInit {
head: string;
postRequestResponse: string;

name:String;
mobile:String;
email:String;

  constructor(private appService: AppService) { }

  ngOnInit() {
  }
   onAddReaderSubmit(){
    console.log('onAddReaderSubmit');
    const reader = {
        name: this.name,
        mobile: this.mobile,
        email: this.email
    };


console.log(reader);
    this.appService.addReader(reader).subscribe((data: any) => {
      this.postRequestResponse = data.content;
});

}
}
