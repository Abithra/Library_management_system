import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';


@Component({
  selector: 'app-borrow-item',
  templateUrl: './borrow-item.component.html',
  styleUrls: ['./borrow-item.component.css']
})
export class BorrowItemComponent implements OnInit {
head: string;
postRequestResponse: string;
isbn:String;
readId:String;
  constructor(private appService: AppService) { }

  ngOnInit() {
  }
   onBorrowSubmit(){
    console.log('onBorrowSubmit');
    const borrowkey = {
        isbn:this.isbn,
        readerId:this.readId
    };


console.log(borrowkey);
    this.appService.borrowItem(borrowkey).subscribe((data: any) => {
      this.postRequestResponse = data.content;
});

}
}
