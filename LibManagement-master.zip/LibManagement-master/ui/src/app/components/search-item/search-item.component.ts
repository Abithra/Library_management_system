import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';

@Component({
  selector: 'app-search-item',
  templateUrl: './search-item.component.html',
  styleUrls: ['./search-item.component.css']
})
export class SearchItemComponent implements OnInit {

head: string;
postRequestResponse: string;
searchKey:String;

  constructor(private appService: AppService) { }

  ngOnInit() {
  }
   onSearchSubmit(){
    console.log('onSearchSubmit');
    const searkey = {
        searchKey:this.searchKey
    };
console.log(searkey);
    this.appService.searchItem(searkey).subscribe((data: any) => {
      this.postRequestResponse = data;
});


}
}
