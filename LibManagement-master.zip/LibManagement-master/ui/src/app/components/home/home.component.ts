import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
head: string;
listRequestResponse: any[];

  constructor(private appService: AppService) { }

  ngOnInit() {

  }


category:String;


listItemClick(item){
this.appService.listItem().subscribe((data: any[]) => {
      this.listRequestResponse = data;
});
console.log(this.listRequestResponse);
this.category=item;
}
listBookClick(book){
this.category=book;
this.appService.listBook().subscribe((data: any) => {
      this.listRequestResponse = data;
});
console.log(this.listRequestResponse);
}
listDVDClick(dvd){
this.category=dvd;
this.appService.listDVD().subscribe((data: any) => {
      this.listRequestResponse = data;
});

}
listReaderClick(reader){
this.category=reader;
this.appService.listReader().subscribe((data: any) => {
      this.listRequestResponse = data;
});

}
listReportClick(report){
this.category=report;
this.appService.listReport().subscribe((data: any) => {
      this.listRequestResponse = data;
});

}
listBookingsClick(bookings){
this.category=bookings;
this.appService.listBookings().subscribe((data: any) => {
      this.listRequestResponse = data;
});

}
}
