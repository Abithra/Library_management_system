import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';


@Component({
  selector: 'app-return-item',
  templateUrl: './return-item.component.html',
  styleUrls: ['./return-item.component.css']
})
export class ReturnItemComponent implements OnInit {

head: string;
postRequestResponse: string;
searchKey:String;

  constructor(private appService: AppService) { }

  ngOnInit() {
  }
   onReturnSubmit(){
    console.log('onReturnSubmit');
    const retkey = {
        searchKey:this.searchKey
    };


console.log(retkey);
    this.appService.returnItem(retkey).subscribe((data: any) => {
      this.postRequestResponse = data.content;
});

}
}
