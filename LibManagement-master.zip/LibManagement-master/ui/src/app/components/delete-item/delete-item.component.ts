import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';


@Component({
  selector: 'app-delete-item',
  templateUrl: './delete-item.component.html',
  styleUrls: ['./delete-item.component.css']
})
export class DeleteItemComponent implements OnInit {
head: string;
postRequestResponse: string;
searchKey:String;
  constructor(private appService: AppService) { }

  ngOnInit() {
  }
   onDeleteSubmit(){
    console.log('onDeleteSubmit');
    const delkey = {
        searchKey:this.searchKey
    };


console.log(delkey);
    this.appService.deleteItem(delkey).subscribe((data: any) => {
      this.postRequestResponse = data.content;
});

}
}
