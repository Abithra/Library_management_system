import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HTTP_INTERCEPTORS, HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { RouteExampleComponent } from './route-example/route-example.component';

import { AppService } from './app.service';
import { AppHttpInterceptorService } from './http-interceptor.service';
import { NavbarComponent } from './components/navbar/navbar.component';
import { AddItemComponent } from './components/add-item/add-item.component';
import { AddReaderComponent } from './components/add-reader/add-reader.component';
import { BorrowItemComponent } from './components/borrow-item/borrow-item.component';
import { DeleteItemComponent } from './components/delete-item/delete-item.component';
import { HomeComponent } from './components/home/home.component';
import { ReturnItemComponent } from './components/return-item/return-item.component';
import { SearchItemComponent } from './components/search-item/search-item.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'add-item', component: AddItemComponent  },
  { path: 'delete-item', component: DeleteItemComponent  },
  { path: 'borrow-item', component: BorrowItemComponent  },
  { path: 'add-reader', component: AddReaderComponent  },
  { path: 'return-item', component: ReturnItemComponent  },
  { path: 'search-item', component: SearchItemComponent  },
  {
    path: 'java',
    component: RouteExampleComponent,
    data: { technology: 'Java' }
  },
  {
    path: 'play',
    component: RouteExampleComponent,
    data: { technology: 'Play' }
  },
  {
    path: 'angular',
    component: RouteExampleComponent,
    data: { technology: 'Angular' }
  },
  {
    path: '**',
    redirectTo: '/play',
    pathMatch: 'full'
  }

];

@NgModule({
  declarations: [
    AppComponent,
    RouteExampleComponent,
    NavbarComponent,
    AddItemComponent,
    AddReaderComponent,
    BorrowItemComponent,
    DeleteItemComponent,
    HomeComponent,
    ReturnItemComponent,
    SearchItemComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    HttpClientXsrfModule.withOptions({
      cookieName: 'Csrf-Token',
      headerName: 'Csrf-Token',
    }),
    RouterModule.forRoot(routes)
  ],
  providers: [
    AppService,
    {
      multi: true,
      provide: HTTP_INTERCEPTORS,
      useClass: AppHttpInterceptorService
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
